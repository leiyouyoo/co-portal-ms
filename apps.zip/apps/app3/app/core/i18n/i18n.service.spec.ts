import { TestBed, TestBedStatic } from '@angular/core/testing';
import { CoLocaleService, SettingsService } from '@co/common';
import { TranslateService } from '@ngx-translate/core';
import { NzI18nService } from 'ng-zorro-antd/i18n';
import { of } from 'rxjs';

import { I18NService } from './i18n.service';

describe('Service: I18n', () => {
  let injector: TestBedStatic;
  let srv: I18NService;
  const MockSettingsService = {
    layout: {
      lang: null,
    },
  };
  const MockNzI18nService = {
    setLocale: () => { },
    setDateLocale: () => { },
  };
  const MockCoLocaleService = {
    setLocale: () => { },
  };
  const MockTranslateService = {
    getBrowserLang: jasmine.createSpy('getBrowserLang'),
    addLangs: () => { },
    setLocale: () => { },
    getDefaultLang: () => '',
    use: (lang: string) => of(lang),
    instant: jasmine.createSpy('instant'),
  };

  function genModule() {
    injector = TestBed.configureTestingModule({
      providers: [
        I18NService,
        { provide: SettingsService, useValue: MockSettingsService },
        { provide: NzI18nService, useValue: MockNzI18nService },
        { provide: CoLocaleService, useValue: MockCoLocaleService },
        { provide: TranslateService, useValue: MockTranslateService },
      ],
    });
    srv = TestBed.inject(I18NService);
  }

  it('should working', () => {
    spyOnProperty(navigator, 'languages').and.returnValue(['zh-CN']);
    genModule();
    expect(srv).toBeTruthy();
    expect(srv.defaultLang).toBe('zh-CN');
    const t = TestBed.inject(TranslateService);
    srv.fanyi('a');
    srv.fanyi('a', {});
    expect(t.instant).toHaveBeenCalled();
  });

  it('should be used layout as default language', () => {
    MockSettingsService.layout.lang = 'en-US';
    const navSpy = spyOnProperty(navigator, 'languages');
    genModule();
    expect(navSpy).not.toHaveBeenCalled();
    expect(srv.defaultLang).toBe('en-US');
    MockSettingsService.layout.lang = null;
  });

  it('should be used browser as default language', () => {
    spyOnProperty(navigator, 'languages').and.returnValue(['zh-TW']);
    genModule();
    expect(srv.defaultLang).toBe('zh-TW');
  });

  it('should be trigger notify when changed language', () => {
    genModule();
    srv.use('en-US');
    srv.change.subscribe((lang) => {
      expect(lang).toBe('en-US');
    });
  });
});
