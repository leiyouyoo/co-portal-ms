import { QuickChatComponent } from './quick-chat.component';
import { QuickChatStatusComponent } from './quick-chat-status.component';

export const QUICK_CHAT_COMPONENTS = [
  QuickChatComponent,
  QuickChatStatusComponent,
];
