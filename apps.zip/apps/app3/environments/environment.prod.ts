export const environment = {
  SERVER_URL: `./`,
  production: true,
  useHash: false,
  hmr: false,
};
